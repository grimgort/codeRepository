#ifndef TD1_H_INCLUDED
#define TD1_H_INCLUDED

#include <vector>
using namespace std ;

string rentrerMot() ;
vector<int> deviner(string motMystere, vector<int>& resultat) ;
string melangeMot(string motMystere) ;
void jeuxTD1(std::vector<int>& resultat) ;
void multiJeux() ;
string mot() ;
int score(std::vector<int>& resultat) ;

#endif // TD1_H_INCLUDED
