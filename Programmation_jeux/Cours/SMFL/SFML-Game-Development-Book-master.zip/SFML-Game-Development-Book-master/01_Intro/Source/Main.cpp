#include <Book/Game.hpp>

int main()
{
	Game game;
    game.run();
}
